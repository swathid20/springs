package coreservlets.actionlistener;

public class ButtonFrame3Test {
  public static void main(String[] args) {
    new ButtonFrame3();
  }
}